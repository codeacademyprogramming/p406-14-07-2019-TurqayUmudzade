function MezunTime(durationInHours,startDate) //determines when you discover if youve wasted 4k or not
{
    var now =startDate;
    var weeks=durationInHours/10;
    now.setDate(now.getDate()+weeks*7);
    console.log(now);
}



function DirDur(day) // 
{
    if (day % 10 == 3 || day % 10 == 4) 
        console.log('Bu gun ayin '+day+ '-dür');
    
        else if (day == 10 || day == 30 || day % 10 == 9) 
        console.log('Bu gun ayin '+day+ '-dur');
    
else 
console.log('Bu gun ayin '+day+ '-dir');
    
}



function quarter(date) //checks the quarter of the year according to date of today
{ 
var date = new Date();

    if (date.getMonth() < 3) 
        console.log('1st quarter');

        else if ( date.getMonth() < 6) 
          console.log('2nd quarter');

            else if (date.getMonth() < 9) 
                console.log('3rd quarter');

else  
console.log('4th quarter');

}



/////////////////////////////////////////////////////////////////////////////////// MAIN \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

/* DirDur(13);
DirDur(10);
DirDur(1); */

/* quarter( new Date); */

/* MezunTime(350,new Date(2019,4,2)); */
